void *mxmalloc(size_t size);
void *mxcalloc(size_t nmemb, size_t size);
void *mxrealloc(void *ptr, size_t size);
void mxfree( void *ptr, size_t size);
